/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Gui;

import Logica.*;
import TDA.ListaSimple;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;
import org.graphstream.ui.view.Viewer;
import org.graphstream.ui.swing_viewer.SwingViewer;
import org.graphstream.ui.swing_viewer.ViewPanel;
import javax.swing.*;
import java.awt.BorderLayout;
import Persistencia.ManejadorCSV;
import Algoritmos.AlgoritmosGrafo;

/**
 *
 * @author abrah
 */
/**
 * Interfaz principal del proyecto BioGraph.
 * Gestiona la interacción entre el usuario y la red de proteínas.
 */

public class MainFrame extends javax.swing.JFrame {
        
    private GrafoProteinas grafoLogico;
    private Graph grafoVisual;
    private ViewPanel viewPanel;
    private String rutaArchivo = "maestro.csv"; // Ruta por defecto
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MainFrame.class.getName());

    /**
     * Creates new form MainFrame
     */
    public MainFrame() {
        // 1. Configuración de UI
    System.setProperty("org.graphstream.ui", "swing");
    
    // 2. ESTO SOLO UNA VEZ (lo genera NetBeans automáticamente)
    initComponents(); 
    
    // 3. Tus inicializaciones
    this.grafoLogico = new GrafoProteinas();
    inicializarGrafoVisual();
    }
    /**
     * Inicializa el motor visual de GraphStream y lo embebe en el JPanel de NetBeans.
     */
    
    private void inicializarGrafoVisual() {
        grafoVisual = new SingleGraph("RedProteica");
        
        // Estilo CSS para que el grafo se vea profesional
        String styleSheet = 
    "node { " +
    "   fill-color: #2ecc71; " +
    "   size: 25px; " +
    "   text-size: 14px; " +
    "   text-alignment: above; " +
    "   text-background-mode: plain; " +
    "}" +
    "node.hub { " +
    "   fill-color: #e74c3c; " +
    "   size: 35px; " +
    "}" +
    "edge { " +
    "   fill-color: #7f8c8d; " +
    "   text-size: 12px; " +
    "}" +
    "edge.ruta { "+
"   fill-color: #f1c40f; " + // Amarillo brillante
"   stroke-width: 5px; " +   // Más grueso para que resalte
"   z-index: 999; " +        // Obliga a la línea a estar al frente
"}" +
"node.ruta { " +             // También podemos resaltar los nodos del camino
"   stroke-mode: plain; " +
"   stroke-color: #f1c40f; " +
"   stroke-width: 3px; " +
    "}";
        
        grafoVisual.setAttribute("ui.stylesheet", styleSheet);
        grafoVisual.setAttribute("ui.antialias");

        
        
        // Crear el visor y el panel
        Viewer viewer = new SwingViewer(grafoVisual, Viewer.ThreadingModel.GRAPH_IN_ANOTHER_THREAD);
        viewer.enableAutoLayout(); // <--- IMPORTANTE: No usamos coordenadas exactas
        viewPanel = (ViewPanel) viewer.addDefaultView(false);
        // Justo después de crear el viewPanel
viewPanel.setPreferredSize(panelGrafo.getSize()); // Toma el tamaño del panel gris
panelGrafo.setLayout(new java.awt.BorderLayout());
panelGrafo.add(viewPanel, java.awt.BorderLayout.CENTER);

// Justo después de viewer.enableAutoLayout();
viewer.enableAutoLayout();
/// Dentro de inicializarGrafoVisual
viewer.enableAutoLayout();

// Aumenta la longitud de las conexiones (3.0 es bastante largo, 1.0 es el default)
grafoVisual.setAttribute("layout.weight", 8.0); 

// Esto define qué tan dispersos pueden estar los nodos antes de dejar de moverse
grafoVisual.setAttribute("layout.stabilization-limit", 0.9);

// Mantenemos tu 0.1 que te gustó para la legibilidad
grafoVisual.setAttribute("layout.force", 0.1);

        // Meter el panel de GraphStream dentro del JPanel de NetBeans
    panelGrafo.setLayout(new BorderLayout());
    panelGrafo.removeAll(); // <--- IMPORTANTE: Limpia lo anterior
    panelGrafo.add(viewPanel, BorderLayout.CENTER);
    // Dentro de inicializarGrafoVisual
        viewer.enableAutoLayout(); // Esto hace que los nodos se repelan entre sí
    // Forzar a Swing a reconocer el nuevo componente
    panelGrafo.revalidate();
    panelGrafo.repaint();
    }

    /**
     * Sincroniza el grafo lógico (nuestros TDAs) con la representación visual.
     */
    private void actualizarVista() {
        grafoVisual.clear();
        inicializarGrafoVisual(); // Reiniciamos para aplicar estilos base

        // Agregar Nodos
        for (int i = 0; i < grafoLogico.vertices.tamanio(); i++) {
            Vertice v = grafoLogico.vertices.obtener(i);
            Node n = grafoVisual.addNode(v.nombre);
            n.setAttribute("ui.label", v.nombre);
        }

        // Agregar Aristas
        for (int i = 0; i < grafoLogico.vertices.tamanio(); i++) {
            Vertice v = grafoLogico.vertices.obtener(i);
            for (int j = 0; j < v.adyacentes.tamanio(); j++) {
                Arista a = v.adyacentes.obtener(j);
                // Evitar duplicados visuales (P1-P2 es igual a P2-P1)
                if (v.nombre.compareTo(a.destino.nombre) < 0) {
                    String id = v.nombre + "-" + a.destino.nombre;
                    Edge e = grafoVisual.addEdge(id, v.nombre, a.destino.nombre);
                    e.setAttribute("ui.label", a.peso);
                    
                    // ... todo tu código de agregar nodos y aristas ...
                    
    panelGrafo.revalidate(); // Le dice al panel que se reorganice
    panelGrafo.repaint();    // Le dice al panel que se pinte de nuevo
                }
            }
        }
    }
    private void reiniciarTodo() {
    // 1. Limpiar los datos lógicos (tus TDAs)
    // Asumiendo que crear un objeto nuevo es más fácil que implementar un método clear() en tu TDA
    this.grafoLogico = new Logica.GrafoProteinas(); 

    // 2. Limpiar el grafo visual de GraphStream
    if (grafoVisual != null) {
        grafoVisual.clear();
    }

    // 3. Quitar el panel visual viejo de Swing y forzar la recreación del visor
    panelGrafo.removeAll();
    viewPanel = null; // Importante para forzar a inicializarGrafoVisual a crear uno nuevo

    // 4. Refrescar el estado del panel de Swing
    panelGrafo.revalidate();
    panelGrafo.repaint();
}
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelGrafo = new javax.swing.JPanel();
        panelControles = new javax.swing.JPanel();
        btnCargar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnAgregarProteina = new javax.swing.JButton();
        btnEliminarProteina = new javax.swing.JButton();
        btnAgregarInteraccion = new javax.swing.JButton();
        btnEliminarInteraccion = new javax.swing.JButton();
        btnRuta = new javax.swing.JButton();
        btnComplejos = new javax.swing.JButton();
        btnHub = new javax.swing.JButton();
        btnComoUsar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout panelGrafoLayout = new javax.swing.GroupLayout(panelGrafo);
        panelGrafo.setLayout(panelGrafoLayout);
        panelGrafoLayout.setHorizontalGroup(
            panelGrafoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 418, Short.MAX_VALUE)
        );
        panelGrafoLayout.setVerticalGroup(
            panelGrafoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 261, Short.MAX_VALUE)
        );

        btnCargar.setText("Cargar");
        btnCargar.addActionListener(this::btnCargarActionPerformed);

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(this::btnGuardarActionPerformed);

        btnAgregarProteina.setText("Agregar Proteina");
        btnAgregarProteina.addActionListener(this::btnAgregarProteinaActionPerformed);

        btnEliminarProteina.setText("Eliminar Proteina");
        btnEliminarProteina.addActionListener(this::btnEliminarProteinaActionPerformed);

        btnAgregarInteraccion.setText("Agregar Interaccion");
        btnAgregarInteraccion.addActionListener(this::btnAgregarInteraccionActionPerformed);

        btnEliminarInteraccion.setText("Eliminar Interaccion");
        btnEliminarInteraccion.addActionListener(this::btnEliminarInteraccionActionPerformed);

        btnRuta.setText("Ruta mas corta");
        btnRuta.addActionListener(this::btnRutaActionPerformed);

        btnComplejos.setText("Detectar Complejos");
        btnComplejos.addActionListener(this::btnComplejosActionPerformed);

        btnHub.setText("Identificar el Hub");
        btnHub.addActionListener(this::btnHubActionPerformed);

        javax.swing.GroupLayout panelControlesLayout = new javax.swing.GroupLayout(panelControles);
        panelControles.setLayout(panelControlesLayout);
        panelControlesLayout.setHorizontalGroup(
            panelControlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelControlesLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(panelControlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panelControlesLayout.createSequentialGroup()
                        .addComponent(btnAgregarInteraccion)
                        .addGap(34, 34, 34)
                        .addComponent(btnEliminarInteraccion)
                        .addGap(26, 26, 26)
                        .addComponent(btnRuta)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnComplejos))
                    .addGroup(panelControlesLayout.createSequentialGroup()
                        .addComponent(btnCargar)
                        .addGap(31, 31, 31)
                        .addComponent(btnGuardar)
                        .addGap(29, 29, 29)
                        .addComponent(btnAgregarProteina)
                        .addGap(27, 27, 27)
                        .addComponent(btnEliminarProteina)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnHub)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        panelControlesLayout.setVerticalGroup(
            panelControlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelControlesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelControlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCargar)
                    .addComponent(btnGuardar)
                    .addComponent(btnAgregarProteina)
                    .addComponent(btnEliminarProteina)
                    .addComponent(btnHub))
                .addGap(18, 18, 18)
                .addGroup(panelControlesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregarInteraccion)
                    .addComponent(btnEliminarInteraccion)
                    .addComponent(btnRuta)
                    .addComponent(btnComplejos))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        btnComoUsar.setText("Como usar");
        btnComoUsar.addActionListener(this::btnComoUsarActionPerformed);

        btnSalir.setText("Salir");
        btnSalir.addActionListener(this::btnSalirActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(157, 157, 157)
                        .addComponent(panelGrafo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(panelControles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnComoUsar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnSalir)
                                .addGap(13, 13, 13)))))
                .addContainerGap(82, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addComponent(panelGrafo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
                .addComponent(panelControles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnComoUsar)
                    .addComponent(btnSalir))
                .addGap(36, 36, 36))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // =========================================================================
    // LÓGICA DE LOS BOTONES
    // =========================================================================
    
    private void btnCargarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarActionPerformed
        // TODO add your handling code here:
           javax.swing.JFileChooser fileChooser = new javax.swing.JFileChooser();

    // FILTRO: Solo archivos .csv
    javax.swing.filechooser.FileNameExtensionFilter filtro = new javax.swing.filechooser.FileNameExtensionFilter("Archivos CSV (*.csv)", "csv");
    fileChooser.setFileFilter(filtro);

    int seleccion = fileChooser.showOpenDialog(this);
    
    if (seleccion == javax.swing.JFileChooser.APPROVE_OPTION) {
        java.io.File archivo = fileChooser.getSelectedFile();
        String ruta = archivo.getAbsolutePath();

        // VALIDACIÓN DE EXTENSIÓN: Evita errores de archivos que no son texto
        if (!ruta.toLowerCase().endsWith(".csv")) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Formato incorrecto. Por favor, selecciona un archivo .csv válido.", 
                "Error de Archivo", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // === PASO CLAVE: REINICIAR ANTES DE CARGAR ===
            // Esto evita que las proteínas del archivo anterior choquen con las nuevas
            reiniciarTodo();

            // Intentamos cargar el grafo desde el archivo
            Persistencia.ManejadorCSV.cargarGrafoDesdeCSV(ruta, grafoLogico);

            // VALIDACIÓN DE CONTENIDO: Verifica que el TDA no esté vacío
            if (grafoLogico.vertices.tamanio() == 0) {
                javax.swing.JOptionPane.showMessageDialog(this, 
                    "El archivo se leyó, pero no se encontraron datos válidos.", 
                    "Advertencia", 
                    javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }

            // RECONSTRUCCIÓN VISUAL:
            // Siempre llamamos a inicializar porque reiniciarTodo() eliminó el visor previo
            inicializarGrafoVisual();
            actualizarVista();

            // ÉXITO: Solo se muestra si todo el proceso anterior fue correcto
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Datos cargados correctamente.", 
                "Éxito", 
                javax.swing.JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            // Captura errores como el "singleton exception" o fallos de lectura
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Error crítico al procesar el archivo:\n" + e.getMessage(), 
                "Error", 
                javax.swing.JOptionPane.ERROR_MESSAGE);
            
            // Si hubo error, limpiamos lo que haya quedado a medias
            reiniciarTodo();
        }
    }
    }//GEN-LAST:event_btnCargarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:
        
        ManejadorCSV.guardarGrafoEnCSV(rutaArchivo, grafoLogico);
        JOptionPane.showMessageDialog(this, "CSV actualizado correctamente.");
        
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnAgregarProteinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarProteinaActionPerformed
        // TODO add your handling code here:
        String nombre = javax.swing.JOptionPane.showInputDialog(this, "Nombre de la proteína:");
    
    if (nombre != null && !nombre.trim().isEmpty()) {
        nombre = nombre.trim();
        
        // VALIDACIÓN: ¿Ya existe en la lógica?
        if (grafoLogico.obtenerVertice(nombre) != null) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "La proteína '" + nombre + "' ya existe en la red.", 
                "Aviso", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Si no existe, procedemos
        grafoLogico.agregarProteina(nombre);
        actualizarVista();
        javax.swing.JOptionPane.showMessageDialog(this, "Proteína agregada con éxito.");
    }
        
    }//GEN-LAST:event_btnAgregarProteinaActionPerformed

    private void btnEliminarProteinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarProteinaActionPerformed
        // TODO add your handling code here:
        String nombre = javax.swing.JOptionPane.showInputDialog(this, "Nombre de la proteína a eliminar:");
    
    if (nombre != null && !nombre.trim().isEmpty()) {
        nombre = nombre.trim();
        
        // VALIDACIÓN: ¿Existe para poder eliminarla?
        if (grafoLogico.obtenerVertice(nombre) == null) {
            javax.swing.JOptionPane.showMessageDialog(this, 
                "Error: No se encontró la proteína '" + nombre + "'.", 
                "No Encontrado", javax.swing.JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Si existe, eliminamos
        grafoLogico.eliminarProteina(nombre);
        actualizarVista();
        javax.swing.JOptionPane.showMessageDialog(this, "Proteína eliminada correctamente.");
    }
    }//GEN-LAST:event_btnEliminarProteinaActionPerformed

    private void btnRutaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRutaActionPerformed
        // TODO add your handling code here:
        String p1 = JOptionPane.showInputDialog("Proteína origen:");
    String p2 = JOptionPane.showInputDialog("Proteína destino:");
    
    // Cambiamos obtenerRutaMasRapida por dijkstra
    ListaSimple<Vertice> ruta = AlgoritmosGrafo.dijkstra(grafoLogico, p1, p2);
    
    if (ruta != null && ruta.tamanio() > 1) {
        actualizarVista();
        for (int i = 0; i < ruta.tamanio() - 1; i++) {
            String n1 = ruta.obtener(i).nombre;
            String n2 = ruta.obtener(i+1).nombre;
            org.graphstream.graph.Edge e = grafoVisual.getEdge(n1 + "-" + n2);
            if (e == null) e = grafoVisual.getEdge(n2 + "-" + n1);
            if (e != null) e.setAttribute("ui.class", "ruta");
        }
    } else {
        JOptionPane.showMessageDialog(this, "No se encontró una ruta.");
    }
        
    }//GEN-LAST:event_btnRutaActionPerformed

    private void btnHubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHubActionPerformed
        // TODO add your handling code here:
       // VALIDACIÓN: ¿Hay proteínas cargadas?
    if (grafoLogico.vertices.tamanio() == 0) {
        javax.swing.JOptionPane.showMessageDialog(this, 
            "No hay proteínas cargadas para analizar.", 
            "Grafo Vacío", javax.swing.JOptionPane.WARNING_MESSAGE);
        return;
    }

    Logica.Vertice hub = Algoritmos.AlgoritmosGrafo.encontrarHub(grafoLogico);
    
    if (hub != null) {
        // Marcamos visualmente
        org.graphstream.graph.Node n = grafoVisual.getNode(hub.nombre);
        if (n != null) {
            n.setAttribute("ui.class", "hub");
            javax.swing.JOptionPane.showMessageDialog(this, "El HUB es: " + hub.nombre);
        }
    } else {
        javax.swing.JOptionPane.showMessageDialog(this, "No se pudo determinar un HUB (quizás no hay interacciones).");
    }
        
    }//GEN-LAST:event_btnHubActionPerformed

    private void btnComplejosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComplejosActionPerformed
        // TODO add your handling code here:
        
        ListaSimple<ListaSimple<Vertice>> complejos = AlgoritmosGrafo.detectarComplejos(grafoLogico);
        // Podemos asignar colores distintos a cada complejo
        actualizarVista();
        String[] colores = {"#3498db", "#9b59b6", "#e67e22", "#1abc9c"};
        
        for (int i = 0; i < complejos.tamanio(); i++) {
            ListaSimple<Vertice> comp = complejos.obtener(i);
            String color = colores[i % colores.length];
            for (int j = 0; j < comp.tamanio(); j++) {
                grafoVisual.getNode(comp.obtener(j).nombre).setAttribute("ui.style", "fill-color: " + color + ";");
            }
        }
        JOptionPane.showMessageDialog(this, "Se detectaron " + complejos.tamanio() + " complejos proteicos.");
    

    }//GEN-LAST:event_btnComplejosActionPerformed

    private void btnAgregarInteraccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarInteraccionActionPerformed
        // TODO add your handling code here:
        String origen = JOptionPane.showInputDialog(this, "Nombre de la proteína de origen:");
    String destino = JOptionPane.showInputDialog(this, "Nombre de la proteína de destino:");
    String pesoStr = JOptionPane.showInputDialog(this, "Peso de la interacción (número):");

    try {
        if (origen != null && destino != null && pesoStr != null) {
            double peso = Double.parseDouble(pesoStr);
            
            // Verificamos si los vértices existen
            if (grafoLogico.obtenerVertice(origen) != null && grafoLogico.obtenerVertice(destino) != null) {
                grafoLogico.agregarInteraccion(origen, destino, peso);
                actualizarVista(); // Refrescar el grafo visual
                JOptionPane.showMessageDialog(this, "Interacción agregada con éxito.");
            } else {
                JOptionPane.showMessageDialog(this, "Error: Una o ambas proteínas no existen.\nDebes agregarlas primero.");
            }
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Error: El peso debe ser un valor numérico.");
    }
        
    }//GEN-LAST:event_btnAgregarInteraccionActionPerformed

    private void btnEliminarInteraccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarInteraccionActionPerformed
        // TODO add your handling code here:
        String origen = JOptionPane.showInputDialog(this, "Proteína origen de la interacción a eliminar:");
    String destino = JOptionPane.showInputDialog(this, "Proteína destino de la interacción a eliminar:");

    if (origen != null && destino != null) {
        // Llamamos al método que ya arreglamos en GrafoProteinas
        grafoLogico.eliminarInteraccion(origen, destino);
        actualizarVista(); // Refrescar el grafo visual
        JOptionPane.showMessageDialog(this, "Interacción eliminada (si existía).");
    }
        
    }//GEN-LAST:event_btnEliminarInteraccionActionPerformed

    private void btnComoUsarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComoUsarActionPerformed
        // TODO add your handling code here:
        String mensaje = "<html>"
            + "<body style='width: 300px; font-family: sans-serif;'>"
            + "<h2 style='color: #2c3e50;'>Guía de Usuario - BioGraph</h2>"
            + "<hr>"
            + "<b>1. Carga de Datos:</b> Usa el botón <i>Cargar</i> para importar tu archivo .csv con las interacciones.<br><br>"
            + "<b>2. Gestión de Proteínas:</b><br>"
            + "<ul>"
            + "  <li><b>Agregar/Eliminar:</b> Modifica los nodos de la red en tiempo real.</li>"
            + "  <li><b>Interacciones:</b> Crea o elimina enlaces especificando origen, destino y peso.</li>"
            + "</ul>"
            + "<b>3. Análisis Avanzado:</b><br>"
            + "<ul>"
            + "  <li><font color='red'><b>Hub:</b></font> Resalta en rojo la proteína con más conexiones.</li>"
            + "  <li><font color='blue'><b>Complejos:</b></font> Detecta grupos de proteínas altamente conectadas.</li>"
            + "  <li><font color='#f1c40f'><b>Ruta Corta:</b></font> Halla el camino más eficiente entre dos puntos (Dijkstra).</li>"
            + "<hr>"
            + "<center>Desarrollado para Estructura de datos</center>"
            + "<center> Abraham Zerpa, Jesus Bethencourt,  Tiago Goncalves </center>"
            + "<center> :) </center>"
            + "</body>"
            + "</html>";

    javax.swing.JOptionPane.showMessageDialog(this, mensaje, "Ayuda del Sistema", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        
    }//GEN-LAST:event_btnComoUsarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        // TODO add your handling code here:
        // Creamos un cuadro de confirmación
        int respuesta = javax.swing.JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de que deseas salir del programa?",
            "Confirmar Salida",
            javax.swing.JOptionPane.YES_NO_OPTION,
            javax.swing.JOptionPane.QUESTION_MESSAGE
        );

        // Si el usuario responde que SÍ
        if (respuesta == javax.swing.JOptionPane.YES_OPTION) {
            // 1. Detenemos cualquier hilo de GraphStream si fuera necesario
            // 2. Cerramos la ventana
            this.dispose();
            // 3. Terminamos el proceso por completo (Exit Code 0 significa salida normal)
            System.exit(0);
        }

    }//GEN-LAST:event_btnSalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new MainFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarInteraccion;
    private javax.swing.JButton btnAgregarProteina;
    private javax.swing.JButton btnCargar;
    private javax.swing.JButton btnComoUsar;
    private javax.swing.JButton btnComplejos;
    private javax.swing.JButton btnEliminarInteraccion;
    private javax.swing.JButton btnEliminarProteina;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnHub;
    private javax.swing.JButton btnRuta;
    private javax.swing.JButton btnSalir;
    private javax.swing.JPanel panelControles;
    private javax.swing.JPanel panelGrafo;
    // End of variables declaration//GEN-END:variables
}
