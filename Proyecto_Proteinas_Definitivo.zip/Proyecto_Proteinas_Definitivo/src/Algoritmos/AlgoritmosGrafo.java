/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Algoritmos;
import TDA.ListaSimple;
import Logica.Vertice;
import Logica.GrafoProteinas;
import TDA.Cola;
import Logica.Arista;
/**
 *
 * @author abrah
 */
/**
 * Contiene los algoritmos requeridos: Dijkstra, detección de Hubs y BFS/DFS.
 */

public class AlgoritmosGrafo {
    /**
     * Algoritmo de Dijkstra para encontrar la ruta de menor peso.
     */
    /**
     * Calcula la ruta más rápida entre dos proteínas.
     * @param grafo El grafo donde se realizará la búsqueda.
     * @param origenNombre Nombre de la proteína inicial.
     * @param destinoNombre Nombre de la proteína final.
     * @return Una lista con el camino de vértices, o null si no hay ruta.
     */
    
    public static ListaSimple<Vertice> dijkstra(GrafoProteinas grafo, String origenNombre, String destinoNombre) {
        Vertice origen = grafo.obtenerVertice(origenNombre);
        Vertice destino = grafo.obtenerVertice(destinoNombre);
        if (origen == null || destino == null) return null;

        // Inicialización
        for (int i = 0; i < grafo.vertices.tamanio(); i++) {
            Vertice v = grafo.vertices.obtener(i);
            v.distancia = Double.MAX_VALUE;
            v.padre = null;
            v.visitado = false;
        }
        origen.distancia = 0;

        for (int i = 0; i < grafo.vertices.tamanio(); i++) {
            Vertice u = null;
            double min = Double.MAX_VALUE;
            // Buscar el nodo no visitado con la distancia mínima (Simulando PriorityQueue)
            for (int j = 0; j < grafo.vertices.tamanio(); j++) {
                Vertice v = grafo.vertices.obtener(j);
                if (!v.visitado && v.distancia < min) {
                    min = v.distancia;
                    u = v;
                }
            }
            if (u == null || u == destino) break;
            u.visitado = true;

            // Relajación de aristas
            for (int j = 0; j < u.adyacentes.tamanio(); j++) {
                Arista a = u.adyacentes.obtener(j);
                Vertice v = a.destino;
                if (!v.visitado && u.distancia + a.peso < v.distancia) {
                    v.distancia = u.distancia + a.peso;
                    v.padre = u;
                }
            }
        }

        // Reconstruir camino
        ListaSimple<Vertice> camino = new ListaSimple<>();
        Vertice actual = destino;
        if (actual.padre == null && actual != origen) return camino; // No hay ruta
        
        while (actual != null) {
            camino.insertarAlInicio(actual);
            actual = actual.padre;
        }
        return camino;  
    }

    /**
     * Identifica el Hub (proteína con más conexiones, vital para la célula).
     */
    /**
     * Identifica la proteína con más conexiones en la red.
     * @param grafo El grafo a analizar.
     * @return El vértice que actúa como HUB.
     */
    public static Vertice encontrarHub(GrafoProteinas grafo) {
        Vertice hub = null;
        int maxConexiones = -1;
        for (int i = 0; i < grafo.vertices.tamanio(); i++) {
            Vertice v = grafo.vertices.obtener(i);
            if (v.adyacentes.tamanio() > maxConexiones) {
                maxConexiones = v.adyacentes.tamanio();
                hub = v;
            }
        }
        return hub;
    }

    /**
     * Detecta complejos proteicos (Componentes Conexos) usando BFS.
     */
    /**
     * Encuentra grupos de proteínas aisladas o sub-redes.
     * @param grafo El grafo a analizar.
     * @return Una lista que contiene listas de vértices (cada una es un complejo).
     */
    public static ListaSimple<ListaSimple<Vertice>> detectarComplejos(GrafoProteinas grafo) {
        ListaSimple<ListaSimple<Vertice>> complejos = new ListaSimple<>();
        
        for (int i = 0; i < grafo.vertices.tamanio(); i++) {
            grafo.vertices.obtener(i).visitado = false;
        }

        for (int i = 0; i < grafo.vertices.tamanio(); i++) {
            Vertice v = grafo.vertices.obtener(i);
            if (!v.visitado) {
                ListaSimple<Vertice> complejoActual = new ListaSimple<>();
                Cola<Vertice> cola = new Cola<>();
                
                cola.encolar(v);
                v.visitado = true;

                while (!cola.estaVacia()) {
                    Vertice actual = cola.desencolar();
                    complejoActual.insertarAlFinal(actual);

                    for (int j = 0; j < actual.adyacentes.tamanio(); j++) {
                        Vertice vecino = actual.adyacentes.obtener(j).destino;
                        if (!vecino.visitado) {
                            vecino.visitado = true;
                            cola.encolar(vecino);
                        }
                    }
                }
                complejos.insertarAlFinal(complejoActual);
            }
        }
        return complejos;
    }
}
