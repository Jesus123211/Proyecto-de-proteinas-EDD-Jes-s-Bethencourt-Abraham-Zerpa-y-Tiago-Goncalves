/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TDA;

/**
 *
 * @author abrah
 */
/**
 * Clase que representa un nodo genérico para nuestras estructuras de datos (Listas y Colas).
 * @param <T> Tipo de dato que almacenará el nodo.
 */

public class Nodo<T> {
        public T valor;
        public Nodo<T> siguiente;

        public Nodo(T valor) {
        this.valor = valor;
        this.siguiente = null;
    }
}
