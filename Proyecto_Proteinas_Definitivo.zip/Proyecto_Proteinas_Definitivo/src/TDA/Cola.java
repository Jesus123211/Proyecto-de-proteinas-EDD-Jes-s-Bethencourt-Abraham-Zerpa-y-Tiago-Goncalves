/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TDA;

/**
 *
 * @author abrah
 */
/**
 * TDA Cola genérica (FIFO) implementada con nodos. Sustituye a java.util.Queue.
 */

public class Cola<T> {
    private Nodo<T> frente;
    private Nodo<T> fin;

    public void encolar(T valor) {
        Nodo<T> nuevo = new Nodo<>(valor);
        if (fin == null) {
            frente = fin = nuevo;
        } else {
            fin.siguiente = nuevo;
            fin = nuevo;
        }
    }

    public T desencolar() {
        if (frente == null) return null;
        T valor = frente.valor;
        frente = frente.siguiente;
        if (frente == null) fin = null;
        return valor;
    }

    public boolean estaVacia() {
        return frente == null;
    }
}
