/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TDA;

/**
 *
 * @author abrah
 */
/**
 * TDA Lista Enlazada Simple genérica. Sustituye a java.util.ArrayList.
 */

public class ListaSimple<T> {
    private Nodo<T> cabeza;
    private int tamanio;

    public ListaSimple() {
        this.cabeza = null;
        this.tamanio = 0;
    }

    /** Inserta un elemento al final de la lista. */
    public void insertarAlFinal(T valor) {
        Nodo<T> nuevo = new Nodo<>(valor);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo<T> temp = cabeza;
            while (temp.siguiente != null) temp = temp.siguiente;
            temp.siguiente = nuevo;
        }
        tamanio++;
    }

    /** Inserta un elemento al inicio (útil para invertir rutas en Dijkstra). */
    public void insertarAlInicio(T valor) {
        Nodo<T> nuevo = new Nodo<>(valor);
        nuevo.siguiente = cabeza;
        cabeza = nuevo;
        tamanio++;
    }

    /** Obtiene el elemento en un índice específico. */
    public T obtener(int indice) {
        if (indice < 0 || indice >= tamanio) return null;
        Nodo<T> temp = cabeza;
        for (int i = 0; i < indice; i++) temp = temp.siguiente;
        return temp.valor;
    }

    /** Elimina un elemento por su valor. */
    public void eliminar(T valor) {
        if (cabeza == null) return;
        if (cabeza.valor.equals(valor)) {
            cabeza = cabeza.siguiente;
            tamanio--;
            return;
        }
        Nodo<T> temp = cabeza;
        while (temp.siguiente != null && !temp.siguiente.valor.equals(valor)) {
            temp = temp.siguiente;
        }
        if (temp.siguiente != null) {
            temp.siguiente = temp.siguiente.siguiente;
            tamanio--;
        }
    }

    public int tamanio() {
        return tamanio;
    }
}
