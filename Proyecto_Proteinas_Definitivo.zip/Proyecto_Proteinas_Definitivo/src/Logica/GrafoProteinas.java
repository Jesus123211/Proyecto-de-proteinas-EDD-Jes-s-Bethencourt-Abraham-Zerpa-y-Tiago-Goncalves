/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

import TDA.ListaSimple;

/**
 *
 * @author abrah
 */

/**
 * Clase principal que gestiona el grafo de interacciones.
 */
public class GrafoProteinas {
    public ListaSimple<Vertice> vertices;

    public GrafoProteinas() {
        this.vertices = new ListaSimple<>();
    }

    public void agregarProteina(String nombre) {
        if (obtenerVertice(nombre) == null) {
            vertices.insertarAlFinal(new Vertice(nombre));
        }
    }

    public void agregarInteraccion(String origen, String destino, double peso) {
        Vertice vOrigen = obtenerVertice(origen);
        Vertice vDestino = obtenerVertice(destino);

        if (vOrigen != null && vDestino != null) {
            // Asumimos grafo no dirigido (interacción mutua)
            vOrigen.adyacentes.insertarAlFinal(new Arista(vDestino, peso));
            vDestino.adyacentes.insertarAlFinal(new Arista(vOrigen, peso));
        }
    }

    public Vertice obtenerVertice(String nombre) {
        for (int i = 0; i < vertices.tamanio(); i++) {
            Vertice v = vertices.obtener(i);
            if (v.nombre.equals(nombre)) return v;
        }
        return null;
    }
    
    public void eliminarProteina(String nombre) {
        Vertice v = obtenerVertice(nombre);
        if (v == null) return;
        
        // Primero eliminar las aristas que apuntan a este vértice
        for (int i = 0; i < vertices.tamanio(); i++) {
            Vertice actual = vertices.obtener(i);
            eliminarInteraccionInterna(actual, nombre);
        }
        vertices.eliminar(v);
    }

    public void eliminarInteraccion(String origen, String destino) {
        Vertice vOrigen = obtenerVertice(origen);
        Vertice vDestino = obtenerVertice(destino);
        if (vOrigen != null && vDestino != null) {
            eliminarInteraccionInterna(vOrigen, destino);
            eliminarInteraccionInterna(vDestino, origen);
        }
    }

    private void eliminarInteraccionInterna(Vertice v, String destinoNombre) {
        for (int i = 0; i < v.adyacentes.tamanio(); i++) {
            Arista a = v.adyacentes.obtener(i);
            if (a.destino.nombre.equals(destinoNombre)) {
                v.adyacentes.eliminar(a);
                break;
            }
        }
    }
}
