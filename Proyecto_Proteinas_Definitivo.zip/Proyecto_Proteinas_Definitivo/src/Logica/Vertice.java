/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;
import TDA.ListaSimple; // 2. ESTA LÍNEA ES VITAL para que reconozca ListaSimple
/**
 *
 * @author abrah
 */

/**
 * Representa una proteína (nodo) en la red de interacciones.
 */

public class Vertice {
    public String nombre;
    public ListaSimple<Arista> adyacentes;
    
    // Variables de apoyo exclusivas para los algoritmos (BFS, DFS, Dijkstra)
    public boolean visitado;
    public double distancia;
    public Vertice padre;

    public Vertice(String nombre) {
        this.nombre = nombre;
        this.adyacentes = new ListaSimple<>();
    }
}
