/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

/**
 *
 * @author abrah
 */

/**
 * Representa la interacción y el peso entre dos proteínas.
 */
public class Arista {
  public Vertice destino;
    public double peso;

    /**
     * El constructor DEBE recibir un Vertice y un double exactamente.
     */
    public Arista(Vertice destino, double peso) {
        this.destino = destino;
        this.peso = peso;
    }
}
