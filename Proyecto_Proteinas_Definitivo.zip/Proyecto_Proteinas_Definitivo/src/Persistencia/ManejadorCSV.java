/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persistencia;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.FileWriter;
// Importamos tu TDA para que la clase sepa manejar las listas
import TDA.ListaSimple;
import Logica.GrafoProteinas;
import Logica.Vertice;
import Logica.Arista;
/**
 *
 * @author abrah
 */

/**
 * Lee y actualiza el archivo maestro.csv (Proteina1,Proteina2,Peso)
 */
public class ManejadorCSV {
   /**
     * Lee el archivo maestro.csv y construye el grafo de proteínas.
     * @param ruta Ubicación del archivo (ej: "maestro.csv")
     * @param grafo La instancia del grafo donde se volcarán los datos
     */
    public static void cargarGrafoDesdeCSV(String ruta, GrafoProteinas grafo) {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                // El archivo viene como: P1,P2,10
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    String p1 = partes[0].trim();
                    String p2 = partes[1].trim();
                    // El peso es vital para Dijkstra (Ruta más rápida)
                    double peso = Double.parseDouble(partes[2].trim());
                    
                    // Agregamos las proteínas y su interacción
                    grafo.agregarProteina(p1);
                    grafo.agregarProteina(p2);
                    grafo.agregarInteraccion(p1, p2, peso);
                }
            }
        } catch (Exception e) {
            System.err.println("Error al cargar el CSV: " + e.getMessage());
        }
    }

    /**
     * Guarda el estado actual del grafo en el archivo CSV.
     * @param ruta Ubicación del archivo
     * @param grafo El grafo con las proteínas actuales
     */
    public static void guardarGrafoEnCSV(String ruta, GrafoProteinas grafo) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {
            // Recorremos la lista de vértices (proteínas)
            for (int i = 0; i < grafo.vertices.tamanio(); i++) {
                Vertice v = grafo.vertices.obtener(i);
                
                // Recorremos las aristas (interacciones) de cada proteína
                for (int j = 0; j < v.adyacentes.tamanio(); j++) {
                    Arista a = v.adyacentes.obtener(j);
                    
                    // Para no duplicar interacciones en el CSV (ej: P1,P2 y P2,P1),
                    // solo guardamos cuando el nombre de origen es menor alfabéticamente.
                    if (v.nombre.compareTo(a.destino.nombre) < 0) {
                        pw.println(v.nombre + "," + a.destino.nombre + "," + a.peso);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error al guardar el CSV: " + e.getMessage());
        }
    }
}
